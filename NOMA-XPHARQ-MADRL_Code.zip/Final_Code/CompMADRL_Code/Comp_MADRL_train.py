"""
作者：Admin
日期：2022年05月09日
"""
from ast import arg
import datetime
import pprint
import re
from tkinter import font
import copy

import csv

import numpy as np
import random
import os
import matplotlib.pyplot as plt
from tensorboard.backend.event_processing import event_accumulator

# from test_xp_harq import NOMA_Environ
from .Comp_Env import NOMA_Environ

import json
import argparse

import torch
from torch.utils.tensorboard import SummaryWriter
from torch.optim.lr_scheduler import ExponentialLR
import tianshou as ts
from tianshou.exploration import GaussianNoise
from tianshou.data import Batch, VectorReplayBuffer, ReplayBuffer, Collector, PrioritizedReplayBuffer
from tianshou.utils import TensorboardLogger
from tianshou.policy import TD3Policy
from tianshou.utils.net.common import Net
from tianshou.utils.net.continuous import Actor, Critic

import sys
import os 
current_dir = os.path.dirname(os.path.abspath(__file__)) # 获取当前文件的绝对路径
parent_dir = os.path.dirname(current_dir) # 获取上一级目录路径
sys.path.append(parent_dir) # 将上一级目录添加到Python路径
from Actor_Critic_Model import ActorNet, CriticNet


def args_read(args_path):
    args = argparse.ArgumentParser()
    args_dict = vars(args)

    with open(args_path, 'rt') as f:
        args_dict.update(json.load(f))
    return args


def clear_file(fname_arr):
    for fname in fname_arr:
        with open(fname, "w") as file:
            pass


def main(Power_dB, num_user, max_K, epoch = 1000):
    parser = argparse.ArgumentParser()
    parser.add_argument('--use_gpu', type=bool, default=True, help='Whether to use gpu or not')
    parser.add_argument('--gpu_fraction', default=(0.5, 0), help='idx / # of gpu fraction e.g. 1/3, 2/3, 3/3')
    parser.add_argument("--task", type=str, default="TD3-Power-outage-train")
    parser.add_argument('--seed', type=int, default=123, help='Value of random seed')
    parser.add_argument('--reward-threshold', type=float, default=3000000)
    parser.add_argument('--buffer-size', type=int, default=20000)
    parser.add_argument('--hidden-sizes', type=int, nargs='*', default=[128, 128, 128])
    parser.add_argument('--actor-lr', type=float, default=3e-4)
    parser.add_argument('--critic-lr', type=float, default=3e-4)
    parser.add_argument("--gamma", type=float, default=0.95)
    parser.add_argument("--tau", type=float, default=0.01)
    parser.add_argument("--exploration-noise", type=float, default=0.2)
    parser.add_argument("--policy-noise", type=float, default=0.1)
    parser.add_argument("--noise-clip", type=float, default=0.1)
    parser.add_argument("--update-actor-freq", type=int, default=2)
    parser.add_argument("--start-timesteps", type=int, default=20000)
    parser.add_argument("--epoch", type=int, default=epoch)
    parser.add_argument("--step-per-epoch", type=int, default=50000)
    parser.add_argument('--slot-per-test', type=int, default=6000)
    parser.add_argument("--step-per-collect", type=int, default=10)
    parser.add_argument("--update-per-step", type=int, default=1)
    parser.add_argument('--episode-per-test', type=int, default=1)
    
    parser.add_argument("--n-step", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--training-num", type=int, default=1)
    parser.add_argument("--test-num", type=int, default=1)
    parser.add_argument("--logdir", type=str, default="log")
    parser.add_argument("--render", type=float, default=0.)
    parser.add_argument(
        "--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu"
    )
    parser.add_argument("--resume-path", type=str, default=None)
    parser.add_argument("--resume-id", type=str, default=None)
    parser.add_argument(
        "--logger",
        type=str,
        default="tensorboard",
        choices=["tensorboard", "wandb"],
    )
    parser.add_argument("--wandb-project", type=str, default="mujoco.benchmark")
    parser.add_argument(
        "--watch",
        default=False,
        action="store_true",
        help="watch the play of pre-trained policy only",
    )

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    print(torch.cuda.is_available())

    """
    XP-PER-DDPG-power测试
    """
    epsilon=10**-2
    phi=0.4
    alpha = 1
    beta = 2
    args = parser.parse_args()
    max_rate = 5
    #num_user = 4
    
    #Power_dB = 10
    #max_K = 3
    folder_path = os.path.join('Comp_Data', f'{int(Power_dB)}dB_N_{int(num_user)}_K_{int(max_K)}')
    #folder_path = 'DRL_Data/'+str(int(Power_dB))+'dB_N_'+str(int(num_user)) + '/'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"文件夹 '{folder_path}' 已创建")
    else:
        print(f"文件夹 '{folder_path}' 已存在")
    
    txt_train = folder_path + '/train_log.txt'
    csv_train = folder_path + '/train_LTAT.csv'
    txt_test = folder_path + '/test_log.txt'
    csv_test = folder_path + '/test_LTAT.csv'
    clear_file([txt_train, csv_train, txt_test, csv_test])
    
    
    env = NOMA_Environ(Power_dB, max_K, num_user=num_user, epsilon=epsilon, phi=phi, beta=beta, alpha=alpha)
    args.state_shape = env.observation_space[env.agents[0]].shape or env.observation_space[env.agents[0]].n
    args.action_shape = env.action_space[env.agents[0]].shape or env.action_space[env.agents[0]].n
    args.max_action = env.action_space[env.agents[0]].high[0]
    #print(args.action_shape)
    agent_nums = len(env.agents)
    agents = []
    buffers = []
    print("Observations shape:", args.state_shape)
    print("Actions shape:", args.action_shape)
    print("Action range:", np.min(env.action_space[env.agents[0]].low), np.max(env.action_space[env.agents[0]].high))

    # model
    actor_net = ActorNet(args.state_shape, args.action_shape, action_bound=args.max_action)
    actor_optim = torch.optim.Adam(actor_net.parameters(), lr=args.actor_lr)
    scheduler_actor = ExponentialLR(actor_optim, gamma=0.999) # 自动调整学习率
    
    critic1_net = CriticNet(args.state_shape, args.action_shape)
    critic1_optim = torch.optim.Adam(critic1_net.parameters(), lr=args.critic_lr)
    scheduler_critic1 = ExponentialLR(critic1_optim, gamma=0.999)
    
    critic2_net = CriticNet(args.state_shape, args.action_shape)
    critic2_optim = torch.optim.Adam(critic2_net.parameters(), lr=args.critic_lr)
    scheduler_critic2 = ExponentialLR(critic2_optim, gamma=0.999)
    

    agent = TD3Policy(actor_net,
                    actor_optim,
                    critic1_net,
                    critic1_optim,
                    critic2_net,
                    critic2_optim,
                    tau=args.tau,
                    gamma=args.gamma,
                    exploration_noise=GaussianNoise(sigma=args.exploration_noise),
                    policy_noise=args.policy_noise,
                    update_actor_freq=args.update_actor_freq,
                    noise_clip=args.noise_clip,
                    estimation_step=args.n_step,
                    action_space=env.action_space,
                    )



    buffer = PrioritizedReplayBuffer(args.buffer_size, 0.5, 0.5)
    for n in range(agent_nums):
        agents.append(copy.deepcopy(agent))
        agents[n] = agents[n].train()
        buffers.append(copy.deepcopy(buffer))
    
    
    for current_epoch in range(args.epoch):
        state_env = env.reset(True)
        #print(state_env[0])
        done = False
        while not done:
            info = None
            actions_buffer = []
            for n in range(len(agents)):
                state_buffer = Batch(obs=[state_env[n]], state=None, info={})
                #print(state_buffer)
                action = agents[n](state_buffer).act[0]
                action_add_noise = np.clip(agents[n].exploration_noise(act=action.detach().numpy(), batch=state_buffer), 0, 1)
                #print(action_add_noise)
                actions_buffer.append(action_add_noise)
            
            actions_buffer = np.array(actions_buffer).reshape(-1)
            #print(actions_buffer)
            next_state_buffer, reward, done, info = env.step(actions_buffer)
            for n in range(len(agents)):
                #print(f"state_buffer[0]:{state_buffer[0]}")
                buffers[n].add(Batch(obs=state_env[n], act=actions_buffer[n], rew=reward[n],\
                                     done=done, obs_next=next_state_buffer[n], info={}))
                    
            if (buffers[0].__len__() >= args.batch_size) and (env.T_slot % env.update_frequency_of_SGD == env.update_frequency_of_SGD-1):
                #args.exploration_noise *= 0.9
                for n in range(len(agents)):
                    agents[n].set_exp_noise(GaussianNoise(sigma=args.exploration_noise))
                    agents[n].update(sample_size=args.batch_size, buffer=buffers[n])
                scheduler_actor.step()
                scheduler_critic1.step()
                scheduler_critic2.step()
            state_env = next_state_buffer
            
        outage_probability = info['Outage_Probability']
        ave_trans = info['Ave_Trans']
        Total_trans_times = env.T_slot
        with open(txt_train,"a") as file:
            file.write("\n")
            file.write(f"Train_Epoch:{current_epoch}, Explore:{args.exploration_noise}, Outage_Probability:{outage_probability}, Throughput:{env.throughput/Total_trans_times}, System_Throughput:{sum(env.throughput)/Total_trans_times}, Ave_Trans:{ave_trans}")
        with open(csv_train, 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(env.throughput/Total_trans_times)
        
        print(f'Train_Epoch:{current_epoch}')
        print(f'Power_dB:{env.user_power}, User_num:{env.num_user}')
        print(f"Action:{actions_buffer}")
        print(f'Reward:{reward}')
        print(f"OP:{outage_probability}")
        print(f"Throughput:{env.throughput/Total_trans_times}")
        print(f"System_Throughput:{sum(env.throughput)/Total_trans_times}")
        print(f"Ave_Trans:{ave_trans}")
        print(f"Lambda:{env.Lambda}")
        print(f"Mu:{env.mu}")
        
        
        # 测试环境用来测量中断概率和吞吐量
        test_done = False
        test_state = env.reset(False)
        #test_info = None
        while not test_done:
            test_actions = []
            for n in range(len(agents)):
                test_state_buffer = Batch(obs=[test_state[n]], state=None, info={})
                test_action_each_user = agents[n](test_state_buffer).act[0]
                #print(test_action_each_user)
                test_actions.append(test_action_each_user.detach().numpy())
            test_actions = np.array(test_actions).reshape(-1)
            #print(test_actions)
            
            test_next_state, test_reward, test_done, test_info = env.step(test_actions)
            test_state = test_next_state
            #print(f"test_test_pra:{env.test_pra}")
            outage_probability = test_info['Outage_Probability']
            ave_trans = test_info['Ave_Trans']
            Total_trans_times = env.T_slot
        with open(txt_test,"a") as file:
            file.write("\n")
            file.write(f"Test_Epoch:{current_epoch}, Explore:{args.exploration_noise}, Outage_Probability:{outage_probability}, Throughput:{env.throughput/Total_trans_times}, System_Throughput:{sum(env.throughput)/Total_trans_times}, Ave_Trans:{ave_trans}")
                           
        with open(csv_test, 'a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(env.throughput/Total_trans_times)
            
        print(f'Test_Epoch:{current_epoch}')
        #print(f"State:{test_state}")
        print(f"Action:{actions_buffer}")
        print(f'Reward:{test_reward}')
        print(f"OP:{outage_probability}")
        print(f"Throughput:{env.throughput/Total_trans_times}")
        print(f"System_Throughput:{sum(env.throughput)/Total_trans_times}")
        print(f"Ave_Trans:{ave_trans}\n")

if __name__ == '__main__':
    Power_dB_arr = np.array([10,20,30])
    user_num_arr = np.array([2,4,6])
    for num_user in user_num_arr:
        for Power_dB in Power_dB_arr:
            main(Power_dB, num_user)