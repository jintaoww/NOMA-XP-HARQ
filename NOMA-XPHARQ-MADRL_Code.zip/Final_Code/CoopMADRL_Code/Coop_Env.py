# -*- coding:utf-8 -*-
"""
作者：Admin
"""
from typing import Optional, Union

import gym
import numpy as np
from gym import spaces
from gym.core import ObsType
from pettingzoo.utils import agent_selector

class NOMA_Environ(gym.Env):
    def __init__(self, power_db=20, max_K=3, num_user=4, epsilon=10**-2, phi=0.1, beta=50, alpha=10):
        self.user_power = 10**(power_db/10)
        self.sig2_dB = -30  # 环境高斯噪声功率（dB）
        self.sig2 = 10**(self.sig2_dB/10)  # 环境高斯噪声功率（W）
        self.num_user = num_user  # 用户数量
        self.state_dim = self.num_user
        self.action_dim = self.num_user
        self.action_bound = 1.0

        self.channel_correlation = 0.4
        self.alpha = np.array([alpha]*self.num_user)+0.0
        self.beta = np.array([beta]*self.num_user)+0.0
        self.epsilon = np.array([epsilon]*self.num_user)+0.0
        self.phi = phi+0.0
        self.max_round = max_K # 最大传输轮次
        self.std_channel = np.array([1-i*0.1 for i in range(self.num_user)])
        #self.std_channel = np.array([0.7,0.8,0.9,1]) # 每个用户瑞利信道的标准差
        
        self.Lambda = np.zeros(self.num_user)
        self.mu = np.zeros(self.num_user) 
        
        self.update_frequency_of_SGD = 20
        self.agents = ["player_"+str(i) for i in range(self.num_user)]
        self.possible_agents = self.agents[:]
        self._agent_selector = agent_selector(self.agents)
        self.action_space = {i: spaces.Box(low=0, high=10, shape=(1,1), dtype=np.float64) for i in self.agents}
        '''
        self.observation_space = {i: spaces.Box(low=0, high=1000, shape=(3,1), dtype=np.float64) for i in self.agents}
        '''
        self.observation_space = {i: spaces.Box(low=0, high=1000, shape=(self.num_user+1,1), dtype=np.float64) for i in self.agents}
        
        self.decay = 1 # 衰减系数用来控制次梯度
        

    def observation_space(self, agent):
        return self.observation_spaces[agent]

    def action_space(self, agent):
        return self.action_spaces[agent]
    
    def seed(self, seed=None):
        np.random.seed(seed)

    # 生成N个h
    def generate_h(self, correlation, previous_h):
        new_h = np.random.normal(0, self.std_channel/np.sqrt(2), self.num_user) + 1j * np.random.normal(0, self.std_channel/np.sqrt(2), self.num_user)
        new_h = correlation*previous_h + np.sqrt(1-correlation**2)*new_h
        return new_h
        
        

    def compute_effective_rate(self, current_rate):
        
        effective_rate = np.zeros(self.num_user)
        
        self.cur_h = self.generate_h(self.channel_correlation, self.pre_h) # 根据上一轮的信道状态信息生成这一轮的
        self.channal_gain = np.abs(self.cur_h)**2
        received_power = self.user_power * self.channal_gain # P|h|^2
        #print(self.channal_gain)
        
        "根据P|h|^2进行排序,大的先译码"
        decoding_order = np.argsort(-received_power)  # decoding_order[j]=u代表用户u第j个译码
        current_MI = np.zeros(self.num_user)
        
        for rank in range(self.num_user):
            n = decoding_order[rank]
            interference_power_of_NOMA_user = self.sig2 # 计算NOMA用户的总干扰
            for tmp_rank in range(rank+1, self.num_user):
                interference_user = decoding_order[tmp_rank]
                interference_power_of_NOMA_user += received_power[interference_user]
            current_MI[n] = np.log2(1 + received_power[n]/interference_power_of_NOMA_user)
            self.current_AMI[n] += current_MI[n]
        
        "如果当前轮次AMI比和速率大,就判断传输成功"
        for n in range(self.num_user):
            if self.current_AMI[n] >= self.current_round_sumRate[n]:
                effective_rate[n] = self.current_round_sumRate[n]

        return effective_rate

    def step(self, action):
        
        current_rate = np.ones(self.num_user) *1.0*1e9

        self.T_slot += 1
        done = False # 由于假设数据包一直传输,所以任务没有终止
        if self.T_slot >= self.max_time_slot:
            done = True
            
        "如果第K-1轮的速率是R,那下一轮的传输速率要小于R"
        for n in range(self.num_user):
            current_rate[n] = action[n]* self.rate_factor
            #current_rate[n] = min(action[n] * self.rate_factor, self.current_max_rate[n])
            self.current_round_sumRate[n] += current_rate[n] # 计算当前轮次总的传输速率

        #self.test_pra = current_rate.copy()
        #self.current_round_sumRate += current_rate[n]
        effective_rate = self.compute_effective_rate(current_rate)  # 计算做出动作后的有效速率
        indicator_outage = 0 # 判断当前是否中断
        
        
        #print(self.current_round.shape)
        for n in range(self.num_user):
            self.throughput[n] += effective_rate[n]
            if effective_rate[n] > 0:
                self.current_AMI[n] = 0.0
                self.current_round_sumRate[n] = 0
                self.current_max_rate[n] = self.rate_factor #
                
                self.current_round[n] = 0 # 新的一轮开始
                self.total_packet[n] += 1
                
                
            elif effective_rate[n] <= 0:
                if self.current_round[n] < self.max_round:
                    self.current_max_rate[n] = current_rate[n] # 约束下一轮最大的传输速率
                    self.sum_fn_neq_K_1[n] += 1
                    #done = True
                    
                elif self.current_round[n] >= self.max_round: # 中断
                    self.current_AMI[n] = 0.0
                    self.current_round_sumRate[n] = 0
                    self.current_max_rate[n] = self.rate_factor
                    
                    self.total_packet[n] += 1
                    self.current_round[n] = 0 # 新的一轮开始
                    
                    indicator_outage = 1
                    self.num_outage[n] += 1
            self.current_round[n] += 1
        
        
        "计算平均传输次数"
        avg_trans = np.ones(self.num_user)
        if self.T_slot > self.max_round:
            for n in range(self.num_user):
                if self.T_slot == self.sum_fn_neq_K_1[n]:
                    avg_trans[n] = self.T_slot
                else:
                    avg_trans[n] = self.T_slot / (self.T_slot - self.sum_fn_neq_K_1[n])
        #if self.training == False:
        #    print(avg_trans)
        reward_sums = np.zeros(self.num_user)+0.0
        total_reward = 0.0
        if self.training:
            for n in range(self.num_user):
                reward_sums[n] = effective_rate[n] - self.Lambda[n] * (avg_trans[n]*indicator_outage - self.epsilon[n]) \
                    - self.mu[n] * (self.phi - effective_rate[n])
            total_reward = sum(reward_sums) # 所有智能体的奖励和
        
            
            if self.T_slot % self.update_frequency_of_SGD == self.update_frequency_of_SGD-1:
                for n in range(self.num_user):
                    #self.Lambda[n] += self.beta[n] * \
                    #    (avg_trans[n]*self.num_outage[n]/self.T_slot - self.epsilon[n])
                    self.Lambda[n] += self.decay*self.beta[n] * (self.num_outage[n]/self.total_packet[n] - self.epsilon[n])
                    self.Lambda[n] = max(self.Lambda[n], 0.0)
                    
                    self.mu[n] += self.decay*self.alpha[n] * (self.phi - self.throughput[n]/self.T_slot)
                    self.mu[n] = max(self.mu[n], 0.0)
                self.decay *= 0.999
        
        
        
        '''
        self.next_state = np.column_stack([self.current_AMI, self.current_round_sumRate, self.channal_gain]).tolist()
        '''
        self.next_state = np.column_stack((self.current_round_sumRate, np.tile(self.channal_gain, (self.num_user, 1))))
        
        #print(self.next_state)
        outage_probability = np.zeros(self.num_user)
        for n in range(self.num_user):
            if self.total_packet[n] > 0:
                outage_probability[n] = self.num_outage[n]/self.total_packet[n]

        info = {"Outage_Probability": outage_probability, "Ave_Trans": avg_trans}
        
        
        
        "更新下一轮的信道状态信息"
        self.pre_h = self.cur_h.copy()
        self.cur_h = None
        
        return self.next_state, np.array([total_reward] * self.num_user), done, info

    def reset(self, training):
        
        "初始化channel gain"
        self.cur_h = None
        self.pre_h = self.generate_h(np.zeros(self.num_user), np.zeros(self.num_user)) # 相关系数为0初始化
        self.channal_gain = None
        
        self.training = training
        self.rate_factor = 5 # 速率缩放因子
        self.num_outage = np.zeros(self.num_user, dtype=np.float64) # 总的中断次数
        self.total_packet = np.zeros(self.num_user, dtype=np.int64)
        self.current_round = np.ones(self.num_user, dtype=np.int64) # 当前传输轮次
        self.sum_fn_neq_K_1 = np.zeros(self.num_user) # 统计前K-1次译码失败的次数
        self.throughput = np.zeros(self.num_user, dtype=np.float64) # 累计吞吐量
        self.current_AMI = np.zeros(self.num_user, dtype=np.float64) # 当前轮次的累计互信息
        self.current_round_sumRate = np.zeros(self.num_user, dtype=np.float64) # 当前轮次累计速率
        self.current_max_rate = np.ones(self.num_user, dtype=np.float64) * self.rate_factor # 当前轮次的最大传输速率
        self.T_slot = 0 # 第T轮数迭代
        if self.training == True:
            self.max_time_slot = 2000 # 超过这一个时隙数就要重置环境
        else:
            self.max_time_slot = 2000 # 超过这一个时隙数就要重置环境
        '''
        self.current_state = np.column_stack([np.zeros(self.num_user, dtype=np.float64), \
                                              np.zeros(self.num_user, dtype=np.float64), \
                                                  np.abs(self.pre_h)**2]).tolist()
        self.next_state = None
        '''
        self.current_state = np.column_stack((np.zeros(self.num_user), np.tile(np.abs(self.pre_h)**2, (self.num_user, 1))))
        self.next_state = None
        

        #self.test_pra = None
        return self.current_state